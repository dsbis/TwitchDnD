package character;

public enum Ability {

	STR, DEX, CON, INTL, WIS, CHA,
	
}
