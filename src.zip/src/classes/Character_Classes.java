package classes;

public enum Character_Classes
{
	NONE, LIFE_CLERIC, THIEF_ROGUE, CHAMPION_FIGHTER, EVOCATION_WIZARD,
};
