package classes;

public class Feature
{
	String name;
	int level;
	
	public Feature(String g_name, int g_level)
	{
		name = g_name;
		level = g_level;
	}
}
