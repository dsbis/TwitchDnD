package run_that_baby;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JFrame;
import javax.swing.JLabel;

import character.Twitch_Character;
import classes.*;

public class Run_From_The_Dragon
{
	
	public static void main(String args[])
	{
		Twitch_Character twitch;
		//INSERT CHARACTER
		
		
		JFrame characterWindow = new JFrame();
		characterWindow.getContentPane().setBackground(Color.LIGHT_GRAY);
		characterWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		characterWindow.setBounds(540, 540, 540, 1000);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		characterWindow.getContentPane().setLayout(gridBagLayout);
		
		JLabel lblNameTwitch = new JLabel("Name: Twitch");
		GridBagConstraints gbc_lblNameTwitch = new GridBagConstraints();
		gbc_lblNameTwitch.insets = new Insets(0, 0, 5, 5);
		gbc_lblNameTwitch.gridx = 0;
		gbc_lblNameTwitch.gridy = 1;
		characterWindow.getContentPane().add(lblNameTwitch, gbc_lblNameTwitch);
		
		JLabel lblStrength = new JLabel("Strength:");
		GridBagConstraints gbc_lblStrength = new GridBagConstraints();
		gbc_lblStrength.insets = new Insets(0, 0, 5, 5);
		gbc_lblStrength.gridx = 0;
		gbc_lblStrength.gridy = 3;
		characterWindow.getContentPane().add(lblStrength, gbc_lblStrength);
		
		JLabel lblChng = new JLabel("" + twitch.Get_Strength());
		GridBagConstraints gbc_lblChng = new GridBagConstraints();
		gbc_lblChng.insets = new Insets(0, 0, 5, 0);
		gbc_lblChng.gridx = 2;
		gbc_lblChng.gridy = 3;
		characterWindow.getContentPane().add(lblChng, gbc_lblChng);
		
		JLabel lblModifier = new JLabel("Modifier");
		GridBagConstraints gbc_lblModifier = new GridBagConstraints();
		gbc_lblModifier.insets = new Insets(0, 0, 5, 5);
		gbc_lblModifier.gridx = 0;
		gbc_lblModifier.gridy = 4;
		characterWindow.getContentPane().add(lblModifier, gbc_lblModifier);
		
		JLabel lblNewLabel = new JLabel("" + twitch.Get_Strength_mod());
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel.gridx = 2;
		gbc_lblNewLabel.gridy = 4;
		characterWindow.getContentPane().add(lblNewLabel, gbc_lblNewLabel);
		
		JLabel lblDexterity = new JLabel("Dexterity");
		GridBagConstraints gbc_lblDexterity = new GridBagConstraints();
		gbc_lblDexterity.insets = new Insets(0, 0, 5, 5);
		gbc_lblDexterity.gridx = 0;
		gbc_lblDexterity.gridy = 5;
		characterWindow.getContentPane().add(lblDexterity, gbc_lblDexterity);
		
		JLabel lblChng_1 = new JLabel("" + twitch.Get_Dexterity());
		GridBagConstraints gbc_lblChng_1 = new GridBagConstraints();
		gbc_lblChng_1.insets = new Insets(0, 0, 5, 0);
		gbc_lblChng_1.gridx = 2;
		gbc_lblChng_1.gridy = 5;
		characterWindow.getContentPane().add(lblChng_1, gbc_lblChng_1);
		
		JLabel lblModifier_1 = new JLabel("Modifier");
		GridBagConstraints gbc_lblModifier_1 = new GridBagConstraints();
		gbc_lblModifier_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblModifier_1.gridx = 0;
		gbc_lblModifier_1.gridy = 6;
		characterWindow.getContentPane().add(lblModifier_1, gbc_lblModifier_1);
		
		JLabel lblChng_2 = new JLabel("" + twitch.Get_Dexterity_Mod());
		GridBagConstraints gbc_lblChng_2 = new GridBagConstraints();
		gbc_lblChng_2.insets = new Insets(0, 0, 5, 0);
		gbc_lblChng_2.gridx = 2;
		gbc_lblChng_2.gridy = 6;
		characterWindow.getContentPane().add(lblChng_2, gbc_lblChng_2);
		
		JLabel lblConstitution = new JLabel("Constitution");
		GridBagConstraints gbc_lblConstitution = new GridBagConstraints();
		gbc_lblConstitution.insets = new Insets(0, 0, 5, 5);
		gbc_lblConstitution.gridx = 0;
		gbc_lblConstitution.gridy = 7;
		characterWindow.getContentPane().add(lblConstitution, gbc_lblConstitution);
		
		JLabel lblChng_3 = new JLabel("" + twitch.Get_Constitution());
		GridBagConstraints gbc_lblChng_3 = new GridBagConstraints();
		gbc_lblChng_3.insets = new Insets(0, 0, 5, 0);
		gbc_lblChng_3.gridx = 2;
		gbc_lblChng_3.gridy = 7;
		characterWindow.getContentPane().add(lblChng_3, gbc_lblChng_3);
		
		JLabel lblModifier_2 = new JLabel("Modifier");
		GridBagConstraints gbc_lblModifier_2 = new GridBagConstraints();
		gbc_lblModifier_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblModifier_2.gridx = 0;
		gbc_lblModifier_2.gridy = 8;
		characterWindow.getContentPane().add(lblModifier_2, gbc_lblModifier_2);
		
		JLabel lblNewLabel_1 = new JLabel("" + twitch.Get_Constitution_Mod());
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_1.gridx = 2;
		gbc_lblNewLabel_1.gridy = 8;
		characterWindow.getContentPane().add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		JLabel lblIntelligence = new JLabel("Intelligence");
		GridBagConstraints gbc_lblIntelligence = new GridBagConstraints();
		gbc_lblIntelligence.insets = new Insets(0, 0, 5, 5);
		gbc_lblIntelligence.gridx = 0;
		gbc_lblIntelligence.gridy = 9;
		characterWindow.getContentPane().add(lblIntelligence, gbc_lblIntelligence);
		
		JLabel lblChng_4 = new JLabel("" + twitch.Get_Intelligence());
		GridBagConstraints gbc_lblChng_4 = new GridBagConstraints();
		gbc_lblChng_4.insets = new Insets(0, 0, 5, 0);
		gbc_lblChng_4.gridx = 2;
		gbc_lblChng_4.gridy = 9;
		characterWindow.getContentPane().add(lblChng_4, gbc_lblChng_4);
		
		JLabel lblModifier_3 = new JLabel("Modifier");
		GridBagConstraints gbc_lblModifier_3 = new GridBagConstraints();
		gbc_lblModifier_3.insets = new Insets(0, 0, 5, 5);
		gbc_lblModifier_3.gridx = 0;
		gbc_lblModifier_3.gridy = 10;
		characterWindow.getContentPane().add(lblModifier_3, gbc_lblModifier_3);
		
		JLabel lblChng_5 = new JLabel("" + twitch.Get_Intelligence_Mod());
		GridBagConstraints gbc_lblChng_5 = new GridBagConstraints();
		gbc_lblChng_5.insets = new Insets(0, 0, 5, 0);
		gbc_lblChng_5.gridx = 2;
		gbc_lblChng_5.gridy = 10;
		characterWindow.getContentPane().add(lblChng_5, gbc_lblChng_5);
		
		JLabel lblWisdom = new JLabel("Wisdom");
		GridBagConstraints gbc_lblWisdom = new GridBagConstraints();
		gbc_lblWisdom.insets = new Insets(0, 0, 5, 5);
		gbc_lblWisdom.gridx = 0;
		gbc_lblWisdom.gridy = 11;
		characterWindow.getContentPane().add(lblWisdom, gbc_lblWisdom);
		
		JLabel lblChng_6 = new JLabel("" + twitch.Get_Wisdom());
		GridBagConstraints gbc_lblChng_6 = new GridBagConstraints();
		gbc_lblChng_6.insets = new Insets(0, 0, 5, 0);
		gbc_lblChng_6.gridx = 2;
		gbc_lblChng_6.gridy = 11;
		characterWindow.getContentPane().add(lblChng_6, gbc_lblChng_6);
		
		JLabel lblModifier_4 = new JLabel("Modifier");
		GridBagConstraints gbc_lblModifier_4 = new GridBagConstraints();
		gbc_lblModifier_4.insets = new Insets(0, 0, 5, 5);
		gbc_lblModifier_4.gridx = 0;
		gbc_lblModifier_4.gridy = 12;
		characterWindow.getContentPane().add(lblModifier_4, gbc_lblModifier_4);
		
		JLabel lblChng_7 = new JLabel("" + twitch.Get_Wisdom_Mod());
		GridBagConstraints gbc_lblChng_7 = new GridBagConstraints();
		gbc_lblChng_7.insets = new Insets(0, 0, 5, 0);
		gbc_lblChng_7.gridx = 2;
		gbc_lblChng_7.gridy = 12;
		characterWindow.getContentPane().add(lblChng_7, gbc_lblChng_7);
		
		JLabel lblCharisma = new JLabel("Charisma");
		GridBagConstraints gbc_lblCharisma = new GridBagConstraints();
		gbc_lblCharisma.insets = new Insets(0, 0, 5, 5);
		gbc_lblCharisma.gridx = 0;
		gbc_lblCharisma.gridy = 13;
		characterWindow.getContentPane().add(lblCharisma, gbc_lblCharisma);
		
		JLabel lblChng_8 = new JLabel("" + twitch.Get_Charisma());
		GridBagConstraints gbc_lblChng_8 = new GridBagConstraints();
		gbc_lblChng_8.insets = new Insets(0, 0, 5, 0);
		gbc_lblChng_8.gridx = 2;
		gbc_lblChng_8.gridy = 13;
		characterWindow.getContentPane().add(lblChng_8, gbc_lblChng_8);
		
		JLabel lblModifier_5 = new JLabel("Modifier");
		GridBagConstraints gbc_lblModifier_5 = new GridBagConstraints();
		gbc_lblModifier_5.insets = new Insets(0, 0, 0, 5);
		gbc_lblModifier_5.gridx = 0;
		gbc_lblModifier_5.gridy = 14;
		characterWindow.getContentPane().add(lblModifier_5, gbc_lblModifier_5);
		
		JLabel lblNewLabel_2 = new JLabel("" + twitch.Get_Charisma_Mod());
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.gridx = 2;
		gbc_lblNewLabel_2.gridy = 14;
		characterWindow.getContentPane().add(lblNewLabel_2, gbc_lblNewLabel_2);
		characterWindow.setVisible(true);
	}

}
