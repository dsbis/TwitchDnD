package races;

import java.util.ArrayList;

import character.Ability_Bonus;

public class Human implements Race
{
	private final String name = "Human";
	private final int speed = 30;

	public Human()
	{
		
	}
	
	public Ability_Bonus Primary_Bonus() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public Ability_Bonus Secondary_Bonus() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public ArrayList<String> Racial_Feats() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public String Get_Name() {
		return name;
	}

	
	public int Get_Speed() {
		return speed;
	}

}
