package backgrounds;

import character.Proficiencies;

public interface Backgrounds
{
	public Proficiencies[] Get_Background_Proficiencies();
	public String Get_Background_Name();
	public String Get_Background_Feature();
}
